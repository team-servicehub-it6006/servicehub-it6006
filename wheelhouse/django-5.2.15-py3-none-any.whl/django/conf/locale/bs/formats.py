# This file is distributed under the same license as the Django package.
#
# The *_FORMAT strings use the Django date format syntax,
# see https://docs.djangoproject.com/en/dev/ref/templates/builtins/#date
DATE_FORMAT = "j. N Y."
TIME_FORMAT = "G:i"
DATETIME_FORMAT = "j. N. Y. G:i T"
YEAR_MONTH_FORMAT = "F Y."
MONTH_DAY_FORMAT = "j. F"
SHORT_DATE_FORMAT = "Y M j"
# SHORT_DATETIME_FORMAT =
# FIRST_DAY_OF_WEEK =

# The *_INPUT_FORMATS strings use the Python strftime format syntax,
# see https://docs.python.org/library/datetime.html#strftime-strptime-behavior
# DATE_INPUT_FORMATS =
# TIME_INPUT_FORMATS =
# DATETIME_INPUT_FORMATS =
DECIMAL_SEPARATOR = ","
THOUSAND_SEPARATOR = "."
# NUMBER_GROUPING =
